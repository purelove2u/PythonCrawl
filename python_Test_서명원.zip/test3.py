for n in range(5):
    print('*' * (5 - n))
